package com.bredexsw.guidancer.examples.logic.identifier;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.draw2d.ConnectionAnchor;
import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.examples.logicdesigner.edit.GateEditPart;
import org.eclipse.gef.examples.logicdesigner.figures.GateFigure;
import org.eclipse.gef.examples.logicdesigner.model.Gate;

import com.bredexsw.guidancer.gef.identifier.ClassCountEditPartIdentifier;
import com.bredexsw.guidancer.gef.identifier.IEditPartIdentifier;

/**
 * Identifier for Gate Edit Parts.
 *
 * @author BREDEX GmbH (http://www.bredex.de)
 * @created Jun 18, 2009
 * @version $Revision: 1.1 $
 */
public class GateEditPartIdentifier implements IEditPartIdentifier {

	/** the Edit Part for which identifying information will be provided */
    private GateEditPart m_editPart;
    
    /** delegate for providing the identifier string */
    private ClassCountEditPartIdentifier m_delegate;

    /**
     * Constructor
     * 
     * @param editPart The Edit Part for which identifying information will be provided.
     */
    public GateEditPartIdentifier(GateEditPart editPart) {
        m_editPart = editPart;
        m_delegate = new ClassCountEditPartIdentifier(editPart);
    }
    
    /**
     * {@inheritDoc}
     */
    public Map<String, ConnectionAnchor> getConnectionAnchors() {
        Map<String, ConnectionAnchor> anchorMap = 
            new HashMap<String, ConnectionAnchor>();
        
        IFigure figure = m_editPart.getFigure();
        if (figure instanceof GateFigure) {
            GateFigure gateFigure = (GateFigure)figure;

            String [] terminals = 
                new String [] {Gate.TERMINAL_A, Gate.TERMINAL_B};
            
            for (int i = 0; i < terminals.length; i++) {
                anchorMap.put(terminals[i], 
                        gateFigure.getConnectionAnchor(terminals[i]));
            }
            
        }
        
        return anchorMap;
    }

    /**
     * {@inheritDoc}
     */
    public String getIdentifier() {
        return m_delegate.getIdentifier();
    }

}
